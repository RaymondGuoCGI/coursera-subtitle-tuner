# 隐私政策
本扩展不收集、传输或出售任何个人数据。所有设置仅保存在你的浏览器本地（通过 Chrome storage）。

我们不会：
- 收集浏览历史、视频内容或账户信息
- 将任何数据发送到远程服务器
- 与第三方共享任何数据

如有疑问，请联系扩展发布者。

---

# Privacy Policy
This extension does not collect, transmit, or sell any personal data. All settings are stored locally in your browser (via Chrome storage).

We do not:
- Collect browsing history, video content, or account information
- Send any data to remote servers
- Share any data with third parties

If you have questions, please contact the extension publisher.
